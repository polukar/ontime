const MYICONS = {
  arrowDown: '/static/icons/icon-arrow-down.svg'
}

export default MYICONS;