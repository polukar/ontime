export { default as Header } from '../..\\components\\header\\header.vue'
export { default as Nav } from '../..\\components\\nav\\nav.vue'
export { default as Setting } from '../..\\components\\settings\\setting.vue'

export const LazyHeader = import('../..\\components\\header\\header.vue' /* webpackChunkName: "components_header/header" */).then(c => c.default || c)
export const LazyNav = import('../..\\components\\nav\\nav.vue' /* webpackChunkName: "components_nav/nav" */).then(c => c.default || c)
export const LazySetting = import('../..\\components\\settings\\setting.vue' /* webpackChunkName: "components_settings/setting" */).then(c => c.default || c)
