import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _c8f2707a = () => interopDefault(import('..\\node_modules\\@nuxtjs\\svg-sprite\\lib\\pages\\icons-list.vue' /* webpackChunkName: "" */))
const _2d7d5fe3 = () => interopDefault(import('..\\pages\\chart.vue' /* webpackChunkName: "pages/chart" */))
const _5c156216 = () => interopDefault(import('..\\pages\\client.vue' /* webpackChunkName: "pages/client" */))
const _c7cefc46 = () => interopDefault(import('..\\pages\\enter.vue' /* webpackChunkName: "pages/enter" */))
const _3a0fa48c = () => interopDefault(import('..\\pages\\place.vue' /* webpackChunkName: "pages/place" */))
const _c1c9d252 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/_icons",
    component: _c8f2707a,
    name: "icons-list"
  }, {
    path: "/chart",
    component: _2d7d5fe3,
    name: "chart"
  }, {
    path: "/client",
    component: _5c156216,
    name: "client"
  }, {
    path: "/enter",
    component: _c7cefc46,
    name: "enter"
  }, {
    path: "/place",
    component: _3a0fa48c,
    name: "place"
  }, {
    path: "/",
    component: _c1c9d252,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
